document.addEventListener("DOMContentLoaded", function() {
    let inputField = document.querySelector("#id_Questions");

    if (!inputField) {
        console.error("Questions input field not found.");
        return;
    }

    // Ensure the container is inside the correct Django admin field
    let parentDiv = inputField.closest(".form-row") || inputField.closest(".field-Questions");
    if (!parentDiv) {
        console.error("Parent div for Questions field not found.");
        return;
    }

    // Create a container for the question inputs
    let container = document.createElement("div");
    container.id = "questions-container";
    container.style.marginTop = "10px";

    let addButton = document.createElement("button");
    addButton.type = "button";
    addButton.textContent = "➕ Add Question";
    addButton.style.display = "block";
    addButton.style.marginBottom = "10px";
    addButton.style.padding = "5px 10px";
    addButton.style.backgroundColor = "#4CAF50";
    addButton.style.color = "white";
    addButton.style.border = "none";
    addButton.style.cursor = "pointer";
    addButton.style.borderRadius = "5px";

    let questionsList = document.createElement("div");
    questionsList.id = "questions-list";

    container.appendChild(addButton);
    container.appendChild(questionsList);
    parentDiv.appendChild(container);

    let existingQuestions = inputField.value.split(",").map(q => q.trim()).filter(q => q);
    existingQuestions.forEach(addQuestionField);

    addButton.addEventListener("click", function() {
        addQuestionField("");
    });

    function addQuestionField(value) {
        let div = document.createElement("div");
        div.className = "question-item";
        div.style.display = "flex";
        div.style.marginBottom = "5px";

        let input = document.createElement("input");
        input.type = "text";
        input.className = "question-input";
        input.style.marginRight = "10px";
        input.style.width = "80%";
        input.value = value;

        let removeBtn = document.createElement("button");
        removeBtn.textContent = "❌";
        removeBtn.type = "button";
        removeBtn.style.color = "white";
        removeBtn.style.backgroundColor = "red";
        removeBtn.style.border = "none";
        removeBtn.style.cursor = "pointer";
        removeBtn.style.padding = "2px 5px";
        removeBtn.style.borderRadius = "3px";

        removeBtn.addEventListener("click", function() {
            div.remove();
            updateQuestionsField();
        });

        div.appendChild(input);
        div.appendChild(removeBtn);
        questionsList.appendChild(div);

        input.addEventListener("input", updateQuestionsField);
        updateQuestionsField();
    }

    function updateQuestionsField() {
        let values = [];
        document.querySelectorAll(".question-input").forEach(input => {
            if (input.value.trim() !== "") {
                values.push(input.value.trim());
            }
        });
        inputField.value = values.join(", ");
    }
});