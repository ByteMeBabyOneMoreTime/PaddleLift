document.addEventListener("DOMContentLoaded", function () {
    let saveButton = document.querySelector("input[name='_save']");
    if (saveButton) {
        saveButton.addEventListener("click", function (event) {
            if (!confirm("Are you sure you want to save this job listing?")) {
                event.preventDefault();
            }
        });
    }
});
